from freqtrade.strategy.interface import IStrategy  # noqa: F401
